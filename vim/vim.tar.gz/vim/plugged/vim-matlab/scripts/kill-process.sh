#!/bin/sh
pkill -f /MATLAB; pkill -f vim-matlab-server
