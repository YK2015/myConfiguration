function printBackspace(len)

fprintf(repmat('\b', [1 len]));